<?php
// Heading
$_['heading_title']    = '<strong style="color:#0BB3EF">آموزش اپن کارت<strong>';
$_['text_title']    = 'آموزش اپن کارت';

?>