<?php
// Text
$_['text_captcha'] = 'کد امنیتی';

// Entry
//$_['entry_captcha'] = 'Please complete the captcha validation below';
$_['entry_captcha'] = 'کد امنیتی';

// Error
$_['error_captcha'] = 'کد امنیتی نادرست است!';
?>