<?php
// Heading
$_['heading_title']  = 'بازیابی رمز عبور';

// Text
$_['text_password']  = 'لطفا رمز عبور جدید خود را وارد نمایید.';
$_['text_success']   = 'رمز عبور شما با موفقیت بروز شد.';

// Entry
$_['entry_password'] = 'رمز عبور';
$_['entry_confirm']  = 'تکرار رمز عبور';

// Error
$_['error_password'] = 'رمز عبور باید بین 4 تا 20 کاراکتر باشد!';
$_['error_confirm']  = 'رمز عبور با تکرار رمز عبور مطابقت ندارد!';
?>