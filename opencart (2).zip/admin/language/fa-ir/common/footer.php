<?php
// Text
$_['text_footer']  = 'تمامی حقوق برای <a target="_blank" href="https://isabad.com/" title="OpenCartFarsi.Com">اپن کارت فارسی دات کام</a> محفوظ است. &copy; 2009-' . date('Y') . ' ';
$_['text_version'] = 'نسخه %s';
?>