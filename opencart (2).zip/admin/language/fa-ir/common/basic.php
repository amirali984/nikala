<?php
// Text
$_['text_captcha'] = 'کد امنیتی';

// Entry
//$_['entry_captcha'] = 'Enter the code in the box below';
$_['entry_captcha'] = 'کد امنیتی';

// Error
//$_['error_captcha'] = 'کد وارد شده با تصویر هماهنگ نیست!';
$_['error_captcha'] = 'کد امنیتی نادرست است!';
?>