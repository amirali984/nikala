<?php
// Heading
$_['heading_title'] = 'پیشخوان';

// Error
$_['error_install'] = 'هشدار: پوشه Install هنوز وجود دارد و به دلایل امنیتی باید حذف شود!';
?>